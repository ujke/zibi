function result = recgnise()

%%%%%����ȫ�ֱ���%%%%%
global result;
global l;
global x;
global I6;
global I5;


l = getImage();
l1=rgb2gray(l);
bw1=edge(l1,'sobel', 'both');
theta=0:179;
r=radon(bw1,theta);


[m,n]=size(r);
c=1;
for i=1:m
    for j=1:n
        if  r(1,1)<r(i,j)
            r(1,1)=r(i,j);
            c=j;
        end
    end
end



rot=90-c;
pic=imrotate(l,rot,'crop');
pic_gray=rgb2gray(pic);
pic_a=imadjust(pic_gray,[0,0.001],[1,0]);
pic_b=1.3*pic_gray+0.7*pic_a;
pic_c=imadjust(pic_b,[0.5,1],[0,1]);
pic_b_edge=edge(pic_c,'sobel');
se=[1;1;1];
pic_imerode=imerode(pic_b_edge,se);
se=strel('rectangle',[60,60]);
pic_imclose=imclose(pic_imerode,se);
pic_bwareaopen=bwareaopen(pic_imclose,10000);



[y,x]=size(pic_bwareaopen);
I6=double(pic_bwareaopen);
Y1=zeros(y,1);
for i=1:y
    for j=1:x
        if(I6(i,j,1)==1)
            Y1(i,1)= Y1(i,1)+1;
        end
    end
end
[temp MaxY]=max(Y1);
%%


PY1=MaxY;
while ((Y1(PY1,1)>=50)&&(PY1>1))
    PY1=PY1-1;
end
PY2=MaxY;
while ((Y1(PY2,1)>=50)&&(PY2<y))
    PY2=PY2+1;
end
IY=pic(PY1:PY2,:,:);
X1=zeros(1,x);
for j=1:x
    for i=PY1:PY2
        if(I6(i,j,1)==1)
            X1(1,j)= X1(1,j)+1;
        end
    end
end
%%


PX1=1;
while ((X1(1,PX1)<3)&&(PX1<x))
    PX1=PX1+1;
end
PX2=x;
while ((X1(1,PX2)<3)&&(PX2>PX1))
    PX2=PX2-1;
end
dw=pic(PY1:PY2,PX1:PX2,:);
dw_gray=rgb2gray(dw);
dw_gray=imadjust(dw_gray,[0,1],[1,0]);
dw_bw=im2bw(dw_gray);
%%


[m,n]=size(dw_bw);
m1=round(m/3);
m2=round(2*m/3);
n1=round(n/6);
n2=round(n/3);
n3=round(2*n/3);
n4=round(5*n/6);
sum1=sum(sum(dw_bw(m1:m2,n1:n2)));
sum2=sum(sum(dw_bw(m1:m2,n3:n4)));
if sum1>sum2
    dw=imrotate(dw,180,'crop');
end

%%

x=dw;
x1=imresize(x,[236,500]);%
z=imcrop(x1,[270,150,160,65]);%
%%
I=imcrop(x1,[130,60,130,65]);    %
I1=rgb2gray(I);    %ת
I2=medfilt2(I1);    %
I3=imadjust(I2,[0.3,0.5],[0,1],1);
I4=im2bw(I3);
se=strel('rectangle',[3,3]);   %

I5=imdilate(I4,se);            %
I5=imdilate(I5,se);            %
I5=imerode(I5,se);             %
I5=imerode(I5,se);             %
I5=imerode(I5,se);             %
I5=imerode(I5,se);             %
I5=imerode(I5,se);             %
I5=imerode(I5,se);             %
I5=~I5;
%%

[p,n]=size(I5);
X1=1;
while(sum(I5(:,X1))<15&&X1<n)
    X1=X1+1;
end
X2=n;
while(sum(I5(:,X2))<15&&X2>1)
    X2=X2-1;
end

I6=I(:,X1:X2,:);%I6
I7=I4(:,X1:X2); %I7
%%
fR=z(:,:,1);
fG=z(:,:,2);
fB=z(:,:,3);
averageR=mean(mean(fR));
averageG=mean(mean(fG));
averageB=mean(mean(fB));

%%%ͨ��ͼ��RGb�����ж�RMB��ֵ
if averageR-averageG>35
    result=100;
    
else
    
    [m,n]=size(I6);
    
    if(n<=90)
        result=1;
    end
    
    
    
    
    
    if(n>=165&&n<310)
        
        I7=I4(:,X1:X2);%I7
        se=strel('rectangle',[35,5]);
        I8=imdilate(I7,se);
        I9=imerode(I8,se);
        I10=~I9;
        
        [M,N]=size(I10);
        M1=round(M/3);
        M2=round(2*M/3);
        N1=round(N/2);
        ui1=sum(sum(I10(1:M1,1:N1)));
        ui2=sum(sum(I10(M1:M2,1:N1)));
        ui3=sum(sum(I10(M2:M,1:N1)));
        
        
    end
end






